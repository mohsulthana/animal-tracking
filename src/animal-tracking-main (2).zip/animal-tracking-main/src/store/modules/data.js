const state = {
  qrcode: {
    Qrcode: ''
  },
  footages: [],
  animals: [],
  animalcategories: [],
  genders: [],
  firstanimalsnapshot: 0,
  firstanimalcategoriessnapshot: 0,
  firstfootagesnapshot: 0,
  firstgenderssnapshot: 0,
  firstusersnapshot: 0,
  users: [],
  logedinEmail: '',
  password: ''
}

const actions = {}
const mutations = {}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
