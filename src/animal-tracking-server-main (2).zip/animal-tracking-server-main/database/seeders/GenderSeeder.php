<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Arr;

class GenderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $gender = ["Female Breed", "Male Breed"];

        DB::table('gender')->insert([
            'id' => rand(),
            'name' => Arr::random($gender),
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }
}
