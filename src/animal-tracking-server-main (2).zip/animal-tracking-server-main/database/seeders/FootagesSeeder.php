<?php

namespace Database\Seeders;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class FootagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('footages')->insert([
            'animalID' => 'N/A',
            'lat' => '-26.55599918',
            'lng' => '20.28118354',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
