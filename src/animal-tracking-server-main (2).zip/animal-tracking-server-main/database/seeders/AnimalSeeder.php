<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class AnimalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('animals')->insert([
            'alias' => Str::random(30),
            'category' => Str::random(20),
            'gender' => Str::random(20),
            'ip' => Str::random(30),
            'month_age' => rand(2, 50),
            'photo_link' => Str::random(100),
            'qr_code' => Str::random(100),
            'created_date' => now(),
            'deleted_date' => now()
        ]);
    }
}
