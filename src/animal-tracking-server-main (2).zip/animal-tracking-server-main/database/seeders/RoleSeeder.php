<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Arr;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $role = ["admin", "editor"];

        DB::table('role')->insert([
            'id' => rand(),
            'name' => Arr::random($role),
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }
}
