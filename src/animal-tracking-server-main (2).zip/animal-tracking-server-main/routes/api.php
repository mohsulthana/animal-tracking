<?php

use App\Http\Controllers\AnimalCategoriesController;
use App\Http\Controllers\AnimalController;
use App\Http\Controllers\GenderController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UplinkMessageController;
use App\Http\Controllers\UserController;
use App\Http\Middleware\Cors;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\FootageController;

Route::post('/login', [AuthController::class, 'login']);

Route::apiResource('/users', UserController::class);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('uplink-message', [UplinkMessageController::class, 'index']);
    Route::get('total-gender', [AnimalController::class, 'totalAnimalGender']);
    Route::get('role', [RoleController::class, 'index']);
    Route::get('/footage-chart', [FootageController::class, 'footageChart']);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::apiResource('/animals', AnimalController::class);
    Route::apiResource('/footages', FootageController::class);
    Route::apiResource('/category', AnimalCategoriesController::class);
    Route::apiResource('/gender', GenderController::class);
});
