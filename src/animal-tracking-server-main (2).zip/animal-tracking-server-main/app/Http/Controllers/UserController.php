<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserResource;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index()
    {
        $user = User::join('role', 'role.id', '=', 'users.role_id')->select('users.*', 'users.created_at as user_created_at', 'users.updated_at as user_updated_at', 'role.name as role')->latest()->paginate(100);
        return new UserResource($user, "User data", true);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $input = $request->all();

        $validator = Validator::make($request->all(), [
            'firstname' => 'required',
            'surname' => 'required',
            'email' => 'required|email',
            'role_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $user = User::create($input);

        return new UserResource(true, 'New user has been added', $user);
    }

    public function destroy($id)
    {
        $user = User::find($id);

        if ($user === null) {
            $resource = new UserResource($user);
            return $resource->response()->setStatusCode(404);
        }

        return new UserResource($user, 'User has been deleted', true);
    }
}
