<?php

namespace App\Http\Controllers;

use App\Models\UplinkMessage;
use App\Http\Resources\UplinkMessageResource as UplinkResource;
use Illuminate\Http\Request;

class UplinkMessageController extends Controller
{
    public function index()
    {
        $uplink = UplinkMessage::orderBy('MessageTime', 'asc')->paginate(100);
        return UplinkResource::collection($uplink);
    }
}
