<?php

namespace App\Http\Controllers;

use App\Http\Resources\FootageResource;
use App\Models\Footage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class FootageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $footage = Footage::latest()->paginate(100);
        return new FootageResource(true, "Footage data", $footage);
    }

    public function footageChart()
    {
        $today = Carbon::today();

        // Initialize the arrays to store counts
        $counts = [];

        // Get all footage data
        $footageData = Footage::all();

        foreach ($footageData as $footage) {
            $category = $footage->animalID;
            if (!isset($counts[$category])) {
                $counts[$category] = [
                    'in7days' => array_fill(0, 7, 0),
                    'in1month' => array_fill(0, 4, 0),
                    'in6months' => array_fill(0, 6, 0),
                    'in1year' => array_fill(0, 12, 0),
                ];
            }

            $createdAt = Carbon::parse($footage->created_at);

            // Calculate the differences
            $diffDays = $createdAt->diffInDays($today);
            $diffWeeks = $createdAt->diffInWeeks($today);
            $diffMonths = $createdAt->diffInMonths($today);

            // Update in7days if within the last 7 days
            if ($diffDays < 7) {
                $counts[$category]['in7days'][6 - $diffDays]++;
            }

            // Update in1month if within the last 1 month
            if ($diffWeeks < 4) {
                $counts[$category]['in1month'][3 - $diffWeeks]++;
            }

            // Update in6months if within the last 6 months
            if ($diffMonths < 6) {
                $counts[$category]['in6months'][5 - $diffMonths]++;
            }

            // Update in1year if within the last 12 months
            if ($diffMonths < 12) {
                $counts[$category]['in1year'][11 - $diffMonths]++;
            }
        }

        // Prepare the data for response
        $data = [];
        foreach ($counts as $categoryname => $footages) {
            $data[] = [
                'categoryname' => $categoryname,
                'footages' => [
                    'in7days' => array_reverse($footages['in7days']),
                    'in1month' => array_reverse($footages['in1month']),
                    'in6months' => array_reverse($footages['in6months']),
                    'in1year' => array_reverse($footages['in1year']),
                ]
            ];
        }

        return response()->json([
            'success' => true,
            'message' => 'Footage data grouped by time ranges',
            'data' => $data
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
