<?php

namespace App\Http\Controllers;

use App\Http\Resources\AnimalResource;
use App\Interfaces\AnimalInterface;
use App\Models\Animal;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AnimalController extends BaseController
{
    private AnimalInterface $animalInterface;

    public function __construct(AnimalInterface $animalInterface)
    {
        $this->animalInterface = $animalInterface;
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $animals = Animal::join('gender', 'gender.GID', '=', 'animals.GID')->join('animal_categories', 'animal_categories.id', '=', 'animals.category_id')
            ->select('animals.*', 'animal_categories.name as category', 'gender.created_at as gender_created_at', 'gender.name as gender')
            ->latest()->paginate(10);
        return new AnimalResource($animals, "Animal data", true);
    }

    public function totalAnimalGender()
    {
        $animals = Animal::select('gender.name as gender', DB::raw('MAX(animals.alias) as alias'), DB::raw('COUNT(animals.id) as total_animals'))
            ->join('gender', 'animals.GID', '=', 'gender.GID')
            ->groupBy('gender.name')
            ->get();
        return new AnimalResource($animals, "Animal gender", true);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'alias' => 'required',
            'name' => 'required',
            'category_id' => 'required',
            'month_age' => 'required',
            'GID' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $photo_link = null;
        $qr_code = null;

        if ($request->file('photo_link') !== null) {
            $photo_link = $request->file('photo_link');
            $photo_link->storeAs('public/animals', $photo_link->hashName());
        }

        if ($request->file('qr_code') !== null) {
            $qr_code = $request->file('qr_code');
            $qr_code->storeAs('public/animals', $qr_code->hashName());
        }

        $animal = Animal::create([
            'alias' => $request->alias,
            'name' => $request->name,
            'category_id' => $request->category_id,
            'ip' => $request->ip,
            'month_age' => $request->month_age,
            'photo_link' => $photo_link === null ? null : $photo_link->hashName(),
            'qr_code' => $qr_code === null ? null : $qr_code->hashName(),
            'GID' => $request->GID,
        ]);

        return new AnimalResource($animal, 'Animal data has been added', true);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $animal = Animal::find($id);
        return new AnimalResource($animal, "Animal details", true);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Animal $animal)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Animal $animal)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'alias' => 'required',
            'name' => 'required',
            'category_id' => 'required',
            'ip' => 'required',
            'month_age' => 'required',
            'photo_link' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'qr_code' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'GID' => 'required',
        ]);

        if ($validator->fails()) {
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $animal->alias = $request->input('alias');
        $animal->name = $request->input('name');
        $animal->category_id = $request->input('category_id');
        $animal->ip = $request->input('ip');
        $animal->month_age = $request->input('month_age');
        $animal->GID = $request->input('GID');
        $animal->save();

        return $this->sendResponse(new AnimalResource($animal), 'Animal updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $animal = Animal::find($id);

        if ($animal === null) {
            $resource = new AnimalResource($animal);
            return $resource->response()->setStatusCode(404);
        }

        $animal->delete();

        return new AnimalResource($animal, 'Animal has been deleted', true);
    }
}
