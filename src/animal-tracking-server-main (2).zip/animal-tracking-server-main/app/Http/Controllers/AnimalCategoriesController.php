<?php

namespace App\Http\Controllers;

use App\Models\AnimalCategories;
use App\Http\Resources\AnimalCategoriesResource as CategoriesResource;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class AnimalCategoriesController extends Controller
{
    public function index()
    {
        $categories = AnimalCategories::latest()->paginate(100);
        return new CategoriesResource($categories, "Categories data");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $category = AnimalCategories::create([
            'name' => $request->name
        ]);

        return new CategoriesResource($category, 'Category data has been added', true);
    }

    public function destroy($id)
    {
        $category = AnimalCategories::find($id);

        if ($category === null) {
            $resource = new CategoriesResource($category);
            return $resource->response()->setStatusCode(404);
        }

        $category->delete();

        return new CategoriesResource($category, 'Category has been deleted', true);
    }
}
