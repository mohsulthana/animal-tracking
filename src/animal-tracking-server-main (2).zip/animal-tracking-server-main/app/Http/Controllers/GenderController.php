<?php

namespace App\Http\Controllers;

use App\Http\Resources\GenderResource;
use App\Models\Gender;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class GenderController extends Controller
{
    public function index()
    {
        $gender = Gender::latest()->paginate(100);
        return new GenderResource($gender, "Gender data", true);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $gender = Gender::create([
            'name' => $request->name
        ]);

        return new GenderResource($gender, 'Gender data has been added', true);
    }

    public function destroy($id)
    {
        $gender = Gender::find($id);

        if ($gender === null) {
            $resource = new GenderResource($gender);
            return $resource->response()->setStatusCode(404);
        }

        $gender->delete();

        return new GenderResource($gender, 'Gender has been deleted', true);
    }
}
