<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AnimalResource extends JsonResource
{
    //define properties
    public $status;
    public $message;
    public $resource;

    public static $wrap = 'animals';

    /**
     * __construct
     *
     * @param  bool $status
     * @param  string $message
     * @param  mixed $resource
     * @return void
     */
    public function __construct($resource, $message = '', $status = false)
    {
        parent::__construct($resource);
        $this->status = $status;
        $this->message = $message;
    }
}
