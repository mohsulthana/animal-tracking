<?php

namespace App\Repositories;

use App\Interfaces\AnimalInterface;
use App\Models\Animal;

class AnimalRepository implements AnimalInterface
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function index()
    {
        return Animal::all();
    }

    public function getById($id)
    {
        return Animal::findOrFail($id);
    }

    public function store(array $data)
    {
        return Animal::create($data);
    }

    public function update(array $data, $id)
    {
        return Animal::whereId($id)->update($data);
    }

    public function delete($id)
    {
        Animal::destroy($id);
    }
}
