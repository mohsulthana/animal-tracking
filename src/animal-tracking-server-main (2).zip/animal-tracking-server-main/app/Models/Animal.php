<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;

class Animal extends Model
{
    use HasFactory;

    /**
     * fillable
     *
     * @var array
     */
    protected $fillable = ['alias', 'category_id', 'ip', 'month_age', 'photo_link', 'qr_code', 'GID', 'name'];

    /**
     * image
     *
     * @return Attribute
     */
    protected function photoLink(): Attribute
    {
        return Attribute::make(
            get: fn ($image) => $image ? url('/storage/animals/' . $image) : null,
        );
    }

    protected function qrCode(): Attribute
    {
        return Attribute::make(
            get: fn ($image) => $image ? url('/storage/animals/' . $image) : null,
        );
    }
}
